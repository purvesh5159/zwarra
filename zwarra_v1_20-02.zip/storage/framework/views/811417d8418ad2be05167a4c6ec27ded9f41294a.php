<?php $__env->startComponent('mail::message'); ?>
# Subscription Confirmation

Thank you for subscribing to our service!

We're excited to have you on board. You'll now receive updates, news, and special offers directly to your inbox.

If you have any questions or need assistance, feel free to contact us.

Thanks,<br>
The <?php echo e(env('APP_NAME')); ?> Team
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp_7.3\htdocs\zwarra_v1\resources\views/emails/subscription_confirmation.blade.php ENDPATH**/ ?>