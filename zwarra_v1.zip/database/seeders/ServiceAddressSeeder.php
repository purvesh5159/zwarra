<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\ServiceAddress;
use Faker\Factory as Faker;

class ServiceAddressSeeder extends Seeder
{
    // public function run()
    // {
    //     $faker = Faker::create();

    //     for ($i = 0; $i < 5; $i++) {
    //         ServiceAddress::create([
    //             'AddressLine1' => $faker->streetAddress,
    //             'AddressLine2' => $faker->secondaryAddress,
    //             'Latitude' => $faker->latitude,
    //             'Longitude' => $faker->longitude,
    //             'Href' => '', // Leave it blank for now
    //         ]);
    //     }
    // }
}
