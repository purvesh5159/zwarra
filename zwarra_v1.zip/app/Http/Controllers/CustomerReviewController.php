<?php

namespace App\Http\Controllers;
use App\Models\CustomerReview;

use Illuminate\Http\Request;

class CustomerReviewController extends Controller
{
    public function index()
    {
        $reviews = CustomerReview::all();
        return response()->json($reviews);
    }
}
